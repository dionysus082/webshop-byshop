require('dotenv').config();
const jwt = require('jsonwebtoken');
const AUTH_COOKIE_NAME = 'token';
const JWT_SECRET = process.env.JWT_SECRET;

const authenticateToken = (req, res, next) => {
    const token = req.cookies[AUTH_COOKIE_NAME];

    if (token == null) {
        return res.status(401).json({ success: false, message: 'ไม่ได้รับอนุญาต: ไม่พบโทเค็น' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            res.clearCookie(AUTH_COOKIE_NAME);
            return res.status(403).json({ success: false, message: 'ต้องห้าม โทเค็นไม่ถูกต้องหรือหมดอายุ' });
        }
        req.user = user;
        next();
    });
};

module.exports = authenticateToken;