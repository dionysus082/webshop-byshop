const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { readFromFile, writeToFile } = require('soly-db');
const axios = require('axios');
const qs = require('qs');
const jwt = require('jsonwebtoken');
const router = express.Router();
require('dotenv').config();

const HISTORY_TOPUP_LOCAL = 'history_topup.json';
const VERIFY_SLIP_LOCAL = 'verify_slip.json';
const USERS_LOCAL = 'users.json';

const SECRET_KEY = process.env.JWT_SECRET;

if (!SECRET_KEY || typeof SECRET_KEY !== 'string' || SECRET_KEY.length === 0) {
    console.error("CRITICAL ERROR: SECRET_KEY environment variable is not set or is invalid. Please set process.env.JWT in your .env file.");
}

const BANK_CODES = {
    "002": "ธ.กรุงเทพ",
    "004": "ธ.กสิกรไทย",
    "006": "ธ.กรุงไทย",
    "011": "ธ.ทหารไทยธนชาต",
    "014": "ธ.ไทยพาณิชย์",
    "025": "ธ.กรุงศรีอยุธยา",
    "069": "ธ.เกียรตินาคินภัทร",
    "022": "ธ.ซีไอเอ็มบีไทย",
    "067": "ธ.ทิสโก้",
    "024": "ธ.ยูโอบี",
    "071": "ธ.ไทยเครดิตเพื่อรายย่อย",
    "073": "ธ.แลนด์ แอนด์ เฮ้าส์",
    "070": "ธ.ไอซีบีซี (ไทย)",
    "034": "ธ.เพื่อการเกษตรและสหกรณ์การเกษตร",
    "030": "ธ.ออมสิน",
    "033": "ธ.อาคารสงเคราะห์",
    "066": "ธ.อิสลามแห่งประเทศไทย"
};

const recipient = {
    name: "นาย ปลาตั้งโก๋ สามีมาก",
    number: "// ใส่เลขธนาคาร",
    bank_code: "004"
};

const recordTopupHistory = (username, id_user, transactionDetails, service = "ตรวจสอบสลิป") => {
    const history = readFromFile(HISTORY_TOPUP_LOCAL);
    const newHistory = {
        id: uuidv4(),
        service: service,
        username,
        id_user,
        transactionDetails: {
            amount: transactionDetails.amount,
            transactionId: transactionDetails.transactionId,
            slip_time: transactionDetails.slip_time,
            slip_timestamp: transactionDetails.slip_timestamp,
            sender_name: transactionDetails.sender ? transactionDetails.sender.name : 'N/A',
            sender_bank_name: transactionDetails.sender ? (BANK_CODES[transactionDetails.sender.bank_code] || transactionDetails.sender.bank_name || 'N/A') : 'N/A',
            receiver_name: transactionDetails.receiver ? transactionDetails.receiver.name : 'N/A',
            receiver_bank_name: transactionDetails.receiver ? (BANK_CODES[transactionDetails.receiver.bank_code || transactionDetails.receiver.receiver_code] || transactionDetails.receiver.bank_name || 'N/A') : 'N/A',
            qrcode_text: transactionDetails.qrcode_text,
            check_slip_status: transactionDetails.check_slip,
        },
        timestamp: new Date().toISOString(),
    };
    history.push(newHistory);
    writeToFile(HISTORY_TOPUP_LOCAL, history);
};

const saveVerifiedSlipData = (slipData) => {
    const verifiedSlips = readFromFile(VERIFY_SLIP_LOCAL);
    const newSlipRecord = {
        id: uuidv4(),
        timestamp: new Date().toISOString(),
        ...slipData
    };
    verifiedSlips.push(newSlipRecord);
    writeToFile(VERIFY_SLIP_LOCAL, verifiedSlips);
};

const updateUserPoints = (userId, amount) => {
    const users = readFromFile(USERS_LOCAL);
    const userIndex = users.findIndex(u => u.id === userId);

    if (userIndex !== -1) {
        const user = users[userIndex];
        const currentPoints = parseFloat(user.points || 0);
        const amountToAdd = parseFloat(amount);

        if (!isNaN(amountToAdd)) {
            user.points = (currentPoints + amountToAdd).toFixed(2);
            writeToFile(USERS_LOCAL, users);
            console.log(`User ${user.username} (ID: ${userId}) updated with ${amountToAdd} points. New total: ${user.points}`);
            return true;
        } else {
            console.warn(`Attempted to add non-numeric amount '${amount}' to user ${userId}. Points not updated.`);
            return false;
        }
    } else {
        console.warn(`User with ID ${userId} not found in ${USERS_LOCAL}. Points not updated.`);
        return false;
    }
};

const verifyToken = (req, res, next) => {
    const token = req.cookies.token;

    if (typeof token !== 'string' || token.length === 0) {
        console.error("JWT verification error: Token is missing or not a string.");
        return res.status(401).json({ success: false, massage_th: "ไม่พบโทเค็นหรือไม่ถูกต้อง", massage_en: "No token provided or invalid token format." });
    }

    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        req.user = decoded; 
        next();
    } catch (err) {
        console.error("JWT verification error:", err);
        return res.status(403).json({ success: false, massage_th: "โทเค็นไม่ถูกต้อง", massage_en: "Invalid token." });
    }
};

const extractDigits = (str) => {
    return str ? String(str).replace(/\D/g, '') : '';
};

router.post('/check_slip', verifyToken, async (req, res) => {
    const { qrcode_text } = req.body;
    const username = req.user.username; 
    const id_user = req.user.id; 

    if (!qrcode_text) {
        return res.status(400).json({ success: false, massage_th: "ไม่พบ qrcode_text", massage_en: "qrcode_text is required." });
    }

    try {
        const response = await axios.post(
            'https://byshop.me/api/check_slip',
            qs.stringify({
                keyapi: process.env.APIKEY_BYSHOP,
                action: 'check', 
                qrcode_text: qrcode_text
            }),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        );

        const apiResponse = response.data; 

        if (apiResponse.status === 0) {
            console.warn(`External API returned status 0: ${apiResponse.massage_th}`);
            return res.json({
                success: false,
                massage_th: apiResponse.massage_th,
                massage_en: apiResponse.massage_en
            });
        }

        if (apiResponse.status !== 1) {
             console.error("Unexpected successful status from external API:", apiResponse);
             return res.status(500).json({
                 success: false,
                 massage_th: "สถานะการตอบกลับจาก API ภายนอกไม่ถูกต้อง",
                 massage_en: "Unexpected status from external API."
             });
        }

        const expectedReceiverName = recipient.name;
        const expectedReceiverBankCode = recipient.bank_code;
        const expectedReceiverAccountNumber = recipient.number;

        const actualReceiverName = apiResponse.receiver?.name;
        const actualReceiverBankCode = apiResponse.receiver?.bank_code || apiResponse.receiver?.receiver_code;
        const actualReceiverAccountNumber = apiResponse.receiver?.acc_no;

        const getFirstNamePart = (fullName) => {
            if (!fullName) return '';
            const parts = fullName.split(' ');
            if (parts.length >= 2) {
                return `${parts[0]} ${parts[1]}`.replace(/\s/g, '').toLowerCase();
            }
            return fullName ? fullName.replace(/\s/g, '').toLowerCase() : ''; 
        };

        const normalizedExpectedFirstNamePart = getFirstNamePart(expectedReceiverName);
        const normalizedActualFirstNamePart = getFirstNamePart(actualReceiverName);

        const digitsExpectedAccountNumber = extractDigits(expectedReceiverAccountNumber);
        const digitsActualAccountNumber = extractDigits(actualReceiverAccountNumber);

        let mismatchDetails = [];
        let nameMismatchFound = false;
        let accountNumberMismatchFound = false;
        let bankCodeMismatchFound = false;

        if (normalizedActualFirstNamePart !== normalizedExpectedFirstNamePart) {
            nameMismatchFound = true;
            mismatchDetails.push(`ชื่อผู้รับ (ส่วนต้น) ไม่ตรงกัน`);
        }
        
        if (!digitsExpectedAccountNumber || !digitsActualAccountNumber || !digitsExpectedAccountNumber.includes(digitsActualAccountNumber)) {
            accountNumberMismatchFound = true;
            mismatchDetails.push(`หมายเลขบัญชีไม่ตรงกัน`);
        }

        if (actualReceiverBankCode !== expectedReceiverBankCode) {
            bankCodeMismatchFound = true;
            mismatchDetails.push(`รหัสธนาคารผู้รับไม่ตรงกัน`);
        }

        if (nameMismatchFound || accountNumberMismatchFound || bankCodeMismatchFound) {
            const thaiBankNameExpected = BANK_CODES[expectedReceiverBankCode] || expectedReceiverBankCode;
            const thaiBankNameActual = BANK_CODES[actualReceiverBankCode] || actualReceiverBankCode;
            
            console.warn(`Recipient mismatch for qrcode_text: ${qrcode_text}. Details: ${mismatchDetails.join('; ')}`);
            
            let detailedThaiMessage = `ข้อมูลผู้รับไม่ตรงกับที่กำหนด: `;
            if (nameMismatchFound) {
                detailedThaiMessage += `ชื่อ (คาดหวัง: '${expectedReceiverName.split(' ').slice(0, 2).join(' ')}', ได้รับ: '${actualReceiverName ? actualReceiverName.split(' ').slice(0, 2).join(' ') : 'N/A'}')`;
            }
            if (accountNumberMismatchFound) {
                if (mismatchDetails.length > 0 && nameMismatchFound) detailedThaiMessage += `; `;
                detailedThaiMessage += `หมายเลขบัญชี (คาดหวัง: '${digitsExpectedAccountNumber}', ได้รับ: '${digitsActualAccountNumber}')`;
            }
            if (bankCodeMismatchFound) {
                if (mismatchDetails.length > 0 && (nameMismatchFound || accountNumberMismatchFound)) detailedThaiMessage += `; `;
                detailedThaiMessage += `รหัสธนาคาร (คาดหวัง: '${thaiBankNameExpected}', ได้รับ: '${thaiBankNameActual}')`;
            }
            detailedThaiMessage += ` (สลิปนี้: ชื่อ '${actualReceiverName}' บัญชี '${actualReceiverAccountNumber}' ธ.${thaiBankNameActual} | บัญชีที่กำหนด: ชื่อ '${expectedReceiverName}' บัญชี '${expectedReceiverAccountNumber}' ธ.${thaiBankNameExpected})`;

            return res.status(400).json({
                success: false,
                massage_th: detailedThaiMessage,
                massage_en: `Recipient information does not match. Details: ${mismatchDetails.join('; ')}.`
            });
        }

        const amount = parseFloat(apiResponse.amount);
        if (isNaN(amount) || amount < 50) {
            console.warn(`Amount too low or invalid: ${apiResponse.amount} for qrcode_text: ${qrcode_text}`);
            return res.status(400).json({
                success: false,
                massage_th: `ยอดเงินต้องไม่ต่ำกว่า 50 บาท (ยอดที่ได้รับ: ${apiResponse.amount} บาท)`,
                massage_en: `Amount must be at least 50 Baht (received: ${apiResponse.amount} Baht).`
            });
        }

        if (apiResponse.check_slip === 1) {
            console.warn(`Duplicate slip detected (check_slip = 1) for qrcode_text: ${qrcode_text}`);
            return res.status(409).json({
                success: false,
                massage_th: "สลิปนี้ถูกตรวจสอบไปแล้ว",
                massage_en: "This slip has already been checked."
            });
        }

        recordTopupHistory(username, id_user, apiResponse, "ตรวจสอบสลิป");
        saveVerifiedSlipData(apiResponse);

        const pointsUpdated = updateUserPoints(id_user, amount);

        if (!pointsUpdated) {
            console.error(`Failed to update points for user ${id_user} after successful slip verification.`);
        }

        return res.json({
            success: true,
            massage_th: apiResponse.massage_th, 
            massage_en: apiResponse.massage_en
        });

    } catch (error) {
        console.error("Error checking slip:", error);

        if (axios.isAxiosError(error)) {
            if (error.response) {
                console.error("Error response data from external API:", error.response.data);
                console.error("Error response status from external API:", error.response.status);
                return res.status(error.response.status).json({
                    success: false,
                    massage_th: error.response.data.massage_th || "เกิดข้อผิดพลาดจากบริการภายนอก",
                    massage_en: error.response.data.massage_en || "External service error.",
                    details: error.response.data
                });
            } else if (error.request) {
                console.error("No response received for the request to external API:", error.request);
                return res.status(503).json({ success: false, massage_th: "ไม่สามารถเชื่อมต่อกับบริการภายนอกได้", massage_en: "Could not connect to external service." });
            } else {
                console.error("Error in setting up the request to external API:", error.message);
                return res.status(500).json({ success: false, massage_th: "เกิดข้อผิดพลาดในการตั้งค่าคำขอ", massage_en: "Request setup error." });
            }
        }
        
        return res.status(500).json({ success: false, massage_th: "เกิดข้อผิดพลาดที่ไม่คาดคิด", massage_en: "An unexpected error occurred." });
    }
});

module.exports = router;