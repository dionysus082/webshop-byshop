const express = require('express');
const soly = require('soly-db');
const router = express.Router();

const ORDERS_LOCAL = 'orders.json';

const authenticateToken = require('../middleware/auth.service');

router.get('/', authenticateToken, (req, res) => {
    const { username, email, points } = req.user;
    res.json({ success: true, user: { username, email, points } });
});

router.get('/orders', authenticateToken, (req, res) => {
    const { id: userId } = req.user;

    const allOrders = soly.readFromFile(ORDERS_LOCAL);

    const userOrders = allOrders.filter(order => order.customer_id === userId);

    res.json({ success: true, orders: userOrders });
});

module.exports = router;