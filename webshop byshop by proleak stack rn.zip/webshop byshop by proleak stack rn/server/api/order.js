require('dotenv').config();
const express = require('express');
const axios = require('axios');
const { readFromFile, writeToFile } = require('soly-db');
const multer = require('multer');
const upload = multer();
const qs = require('querystring');
const router = express.Router();

const APIKEY_BYSHOP = process.env.APIKEY_BYSHOP;
const ORDERS_LOCAL = 'orders.json';

if (!APIKEY_BYSHOP) {
    console.error('FATAL ERROR: APIKEY_BYSHOP is not defined. Please set it in your .env file.');
    process.exit(1);
}

const authenticateToken = require('../middleware/auth.service');

// รับค่าจาก form-data (ไม่มีไฟล์)
router.post('/buy', authenticateToken, upload.none(), async (req, res) => {
    const { product_id, quantity } = req.body;
    const { id: user_id, username } = req.user;

    const username_customer = user_id;

    const parsedQuantity = parseInt(quantity, 10);
    if (!product_id || isNaN(parsedQuantity) || parsedQuantity <= 0) {
        return res.status(400).json({ success: false, message: 'กรุณาระบุ ID สินค้าและจำนวนที่ถูกต้อง' });
    }

    const API_URL = 'https://byshop.me/api/buy';
    const API_KEY = APIKEY_BYSHOP;

    let successfulOrders = [];
    let failedOrders = [];

    for (let i = 0; i < parsedQuantity; i++) {
        try {
            const response = await axios.post(API_URL, 
                qs.stringify({
                    id: product_id,
                    keyapi: API_KEY,
                    username_customer
                }),
                {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                }
            );

            if (response.data.status === 'success') {
                successfulOrders.push(response.data);

                const ordersHistory = readFromFile(ORDERS_LOCAL);
                ordersHistory.push({
                    ...response.data,
                    customer_id: username_customer,
                    customer_username: username,
                    timestamp: new Date().toISOString()
                });
                writeToFile(ORDERS_LOCAL, ordersHistory);
            } else {
                failedOrders.push({
                    attempt: i + 1,
                    message: response.data.message || 'Unknown error from external API'
                });
                if (response.data.message === 'ยอดเงินไม่เพียงพอ') {
                    console.warn(`การสั่งซื้อครั้งที่ ${i + 1} ล้มเหลว: ยอดเงินไม่เพียงพอ`);
                    break;
                }
            }
        } catch (error) {
            console.error('Error calling ByShop API:', error.message);
            failedOrders.push({
                attempt: i + 1,
                message: error.message || 'Network or internal server error'
            });
            break;
        }
    }

    if (successfulOrders.length > 0) {
        res.json({
            success: true,
            message: `สั่งซื้อสำเร็จ ${successfulOrders.length} รายการ`,
            successfulOrders,
            failedOrders
        });
    } else {
        res.status(500).json({
            success: false,
            message: `ไม่สามารถสั่งซื้อได้เลย ${failedOrders.length} รายการ`,
            failedOrders
        });
    }
});

module.exports = router;