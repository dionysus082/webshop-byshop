require('dotenv').config();
const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const { readFromFile, writeToFile } = require('soly-db');
const router = express.Router();

const authenticateToken = require('../middleware/auth.service');

const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
    console.error('FATAL ERROR: JWT_SECRET is not defined. Please set it in your .env file.');
    process.exit(1);
}

const AUTH_COOKIE_NAME = 'token';
const USERS_LOCAL = 'users.json';

router.post('/register', async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ success: false, message: 'กรุณาระบุชื่อผู้ใช้, อีเมล และรหัสผ่าน' });
    }

    const users = readFromFile(USERS_LOCAL);

    if (users.some(user => user.username === username)) {
        return res.status(409).json({ success: false, message: 'ชื่อผู้ใช้นี้มีอยู่แล้ว' });
    }
    if (users.some(user => user.email === email)) {
        return res.status(409).json({ success: false, message: 'อีเมลนี้มีอยู่แล้ว' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = {
            id: uuidv4(),
            username,
            email,
            password: hashedPassword,
            points: 0,
            role: 0,
            timestamp: new Date().toISOString()
        };

        users.push(newUser);
        writeToFile(USERS_LOCAL, users);

        res.status(201).json({ success: true, message: 'ลงทะเบียนผู้ใช้สำเร็จ!', user: { id: newUser.id, username: newUser.username, email: newUser.email } });
    } catch (error) {
        console.error('Error during registration:', error);
        res.status(500).json({ success: false, message: 'เกิดข้อผิดพลาดภายในเซิร์ฟเวอร์ระหว่างการลงทะเบียน' });
    }
});

router.post('/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'กรุณาระบุชื่อผู้ใช้และรหัสผ่าน' });
    }

    const users = readFromFile(USERS_LOCAL);
    const user = users.find(u => u.username === username);

    if (!user) {
        return res.status(401).json({ success: false, message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
    }

    try {
        const isPasswordValid = await bcrypt.compare(password, user.password);

        if (!isPasswordValid) {
            return res.status(401).json({ success: false, message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
        }

        const tokenPayload = {
            id: user.id,
            username: user.username,
            email: user.email,
            points: user.points,
            role: user.role
        };
        const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: '1h' });

        res.cookie(AUTH_COOKIE_NAME, token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: 3600000,
            sameSite: 'Lax'
        });

        res.json({ success: true, message: 'เข้าสู่ระบบสำเร็จ!', user: { id: user.id, username: user.username, email: user.email } });
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ success: false, message: 'เกิดข้อผิดพลาดภายในเซิร์ฟเวอร์ระหว่างการเข้าสู่ระบบ' });
    }
});

router.get('/logout', (req, res) => {
    res.clearCookie(AUTH_COOKIE_NAME);
    res.json({ success: true, message: 'ออกจากระบบสำเร็จ!' });
});

router.get('/verify', authenticateToken, (req, res) => {
    const userId = req.user.id;
    const users = readFromFile(USERS_LOCAL);
    const user = users.find(user => user.id === userId);

    if (user) {
        const isAdmin = req.user.role === 1;
        res.json({
            success: true,
            admin: isAdmin
        });
    } else {
        res.status(404).json({
            success: false
        });
    }
});

module.exports = router;