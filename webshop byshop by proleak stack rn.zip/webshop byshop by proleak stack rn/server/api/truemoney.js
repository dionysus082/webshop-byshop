const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const soly = require('soly-db');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const qs = require('qs');
require("dotenv").config();

const USERS_LOCAL = 'users.json';
const HISTORY_TOPUP_LOCAL = 'history_topup.json';
const jwtSecret = process.env.JWT_SECRET;
const phonenumber = process.env.PHONE_NUMBER;
const API_KEY_BYSHOP = process.env.APIKEY_BYSHOP;

const recordTopupHistory = (username, id_user, transactionDetails, service = "ตรวจสอบสลิป") => {
    const history = readFromFile(HISTORY_TOPUP_LOCAL);
    const newHistory = {
        id: uuidv4(),
        service: service,
        username,
        id_user,
        transactionDetails: {
            amount: transactionDetails.amount,
            transactionId: transactionDetails.transactionId,
            slip_time: transactionDetails.slip_time,
            slip_timestamp: transactionDetails.slip_timestamp,
            sender_name: transactionDetails.sender ? transactionDetails.sender.name : 'N/A',
            sender_bank_name: transactionDetails.sender ? (BANK_CODES[transactionDetails.sender.bank_code] || transactionDetails.sender.bank_name || 'N/A') : 'N/A',
            receiver_name: transactionDetails.receiver ? transactionDetails.receiver.name : 'N/A',
            receiver_bank_name: transactionDetails.receiver ? (BANK_CODES[transactionDetails.receiver.bank_code || transactionDetails.receiver.receiver_code] || transactionDetails.receiver.bank_name || 'N/A') : 'N/A',
            qrcode_text: transactionDetails.qrcode_text,
            check_slip_status: transactionDetails.check_slip,
        },
        timestamp: new Date().toISOString(),
    };
    history.push(newHistory);
    writeToFile(HISTORY_TOPUP_LOCAL, history);
};

function getErrorMessage(errorCode) {
  switch (errorCode) {
    case "ซองเติมเงินนี้ถูกใช้งานไปแล้ว":
      return "ซองนี้ถูกใช้งานแล้ว";
    case "ซองเติมเงินนี้หมดอายุ":
      return "ซองนี้หมดอายุ";
    case "ไม่พบซองอั๋งเปานี้":
      return "ไม่พบซองนี้";
    case "รับซองตัวเองไม่ได้":
      return "ไม่สามารถรับซองของตัวเองได้";
    case "ไม่พบเบอร์นี้ในระบบ":
      return "ไม่พบหมายเลขนี้ในระบบ";
    case "ไม่มีซองนี้ในระบบ หรือ URL ผิด":
      return "ซองของขวัญนี้ไม่ถูกต้องหรือไม่พบ";
    case "บัญชีสร้างซองนี้โดนแบน":
      return "บัญชีที่สร้างซองนี้ถูกแบน";
    case "ผู้รับซองต้องเป็น 1 คน":
      return "ผู้รับซองต้องเป็นเพียง 1 คน";
    default:
      return "เกิดข้อผิดพลาด";
  }
}

router.post("/truemoney", async (req, res) => {
  const { link } = req.body;
  const token = req.cookies.token;
  const tokenuuid = uuidv4();

  if (!link) {
    return res
      .status(400)
      .json({ status: false, message: "ลิ้งซองของขวัญเป็นสิ่งจำเป็น!" });
  }

  try {
    if (!token) {
      return res.status(401).json({ status: false, message: "ไม่พบ token" });
    }

    const decoded = jwt.verify(token, jwtSecret);
    const id_user = decoded.id;

    const users = soly.readFromFile(USERS_LOCAL);
    const user = users.find((user) => user.id === id_user);

    if (!user) {
      return res
        .status(400)
        .json({ status: false, message: "ไม่พบผู้ใช้ที่มีโทเคนนี้" });
    }

    try {
      const response = await axios.post(
        "https://byshop.me/api/truewallet",
        qs.stringify({ phone: phonenumber, gift_link: link, keyapi: API_KEY_BYSHOP }),
        {
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
        }
      );
      const data = response.data;

      const topupHistory = soly.readFromFile(HISTORY_TOPUP_LOCAL);
      topupHistory.push({
        id: tokenuuid,
        status: data.status === 'success' ? true : false,
        service: 'อั่งเปา ทรูมันนี่',
        username: user.username,
        token,
        amount: data.status === "success" ? data.amount : 0,
        phone: phonenumber,
        gift_link: link,
        message: data.message,
        timestamp: new Date().toISOString()
      });
      soly.writeToFile(HISTORY_TOPUP_LOCAL, topupHistory);

      if (data.status === "success") {
        const netAmount = parseFloat(data.amount) || 0;

        if (netAmount < 10) {
          return res.status(400).json({
            status: false,
            message: "ยอดขั้นต่ำในการเติมเงินต้องมากกว่าหรือเท่ากับ 10 บาท",
          });
        }

        user.balance = (parseFloat(user.balance) || 0) + netAmount;
        user.accumulate = (parseFloat(user.accumulate) || 0) + netAmount;
        soly.writeToFile(USERS_LOCAL, users);

        recordTopupHistory(
            user.username,
            id_user,
            {
                amount: data.amount,
                transactionId: data.trans_id || tokenuuid,
                slip_time: data.slip_time || 'N/A',
                slip_timestamp: data.slip_timestamp || Date.now(),
                sender: {
                    name: data.sender_name || 'N/A',
                    bank_code: data.sender_bank_code || '',
                    bank_name: data.sender_bank_name || 'N/A'
                },
                receiver: {
                    name: data.receiver_name || 'N/A',
                    bank_code: data.receiver_bank_code || '',
                    receiver_code: data.receiver_code || '',
                    bank_name: data.receiver_bank_name || 'N/A'
                },
                qrcode_text: data.qrcode_text || '',
                check_slip: data.check_slip || 'N/A'
            },
            "อั่งเปา ทรูมันนี่"
        );

        return res
          .status(200)
          .json({
            status: true,
            message: "สำเร็จ!",
            amount: netAmount,
            fee: 0,
            link: data.gift_link,
          });
      } else {
        return res
          .status(400)
          .json({ status: false, message: getErrorMessage(data.message) });
      }
    } catch (error) {
      console.error(error);
      return res.status(401).json({ status: false, message: "Token ไม่ถูกต้อง" });
    }
  } catch (error) {
    console.error(error);
    return res
      .status(400)
      .json({ status: false, message: "เกิดข้อผิดพลาด โปรดลองอีครั้งในภายหลัง" });
  }
});

module.exports = router;