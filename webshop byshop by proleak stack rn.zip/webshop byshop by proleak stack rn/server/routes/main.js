const express = require('express');
const router = express.Router();

const auth = require('../api/auth');
const profile = require('../api/profile');
const order = require('../api/order');

const truemoney = require('../api/truemoney');
const verify = require('../api/verifyslip');

router.use('/auth', auth);
router.use('/profile', profile);
router.use('/order', order);
router.use('/topup', truemoney, verify);

module.exports = router;