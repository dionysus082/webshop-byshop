import { createContext, useContext, useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import axios from 'axios';
import { serverName } from '@/config/server';

interface AuthContextType {
  isVerified: boolean | null;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType>({
  isVerified: null,
  isAdmin: false,
});

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [isVerified, setIsVerified] = useState<boolean | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);

  useEffect(() => {
    const verifyUser = async () => {
      try {
        const response = await axios.get(`${serverName}/auth/verify`, { withCredentials: true });

        if (response.data.success) {
          setIsVerified(true);
          setIsAdmin(response.data.admin === true);
        } else {
          setIsVerified(false);
          setIsAdmin(false);
        }
      } catch (error) {
        setIsVerified(false);
        setIsAdmin(false);
      }
    };

    verifyUser();
  }, []);

  return (
    <AuthContext.Provider value={{ isVerified, isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);