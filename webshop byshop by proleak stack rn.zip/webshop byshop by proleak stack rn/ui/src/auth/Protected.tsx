import { useAuth } from "@/context/AuthContext";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

interface ProtectedProps {
    children: React.ReactNode;
    redirectTo?: string;
}

function Protected({ children, redirectTo = "/signin"  }: ProtectedProps) {
    const { isVerified } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        if (isVerified === false) {
        navigate(redirectTo);
        }
    }, [isVerified, navigate]);

    if (isVerified === null) {
        return (
          <div className="flex justify-center items-center min-h-screen">
            <p>กำลังตรวจสอบการยืนยันตัวตน...</p>
          </div>
        );
    }

    if (isVerified === true) {
        return <>{children}</>;
    }
  
    return null
}

export default Protected