import { useAuth } from "@/context/AuthContext";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

interface ProtectedProps {
    children: React.ReactNode;
    redirectTo?: string;
}

function ReversProtected({ children, redirectTo = "/"  }: ProtectedProps) {
    const { isVerified } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        if (isVerified === true) {
        navigate(redirectTo);
        }
    }, [isVerified, navigate]);

    if (isVerified === null) {
        return (
          <div className="flex justify-center items-center min-h-screen">
            <p>กำลังตรวจสอบการยืนยันตัวตน...</p>
          </div>
        );
    }

    if (isVerified === false) {
        return <>{children}</>;
    }
  
    return null
}

export default ReversProtected