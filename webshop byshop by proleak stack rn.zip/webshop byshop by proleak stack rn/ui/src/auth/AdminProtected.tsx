import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

interface AdminProtectedProps {
  children: React.ReactNode;
  redirectTo?: string;
}

function AdminProtected({ children, redirectTo = "/" }: AdminProtectedProps) {
  const { isVerified, isAdmin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isVerified === false || isAdmin === false) {
      navigate(redirectTo);
    }
  }, [isVerified, isAdmin, navigate]);

  if (isVerified === null) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p>กำลังตรวจสอบสิทธิ์ผู้ดูแลระบบ...</p>
      </div>
    );
  }

  if (isVerified && isAdmin) {
    return <>{children}</>;
  }

  return null;
}

export default AdminProtected;