import './App.css';

import Nav from './components/Nav';
import Header from './components/Header';
import ProductR from './components/ProductR';
import Footer from './components/Footer';

function App() {
  return (
    <>
      <Nav />
      <main className='min-h-screen'>
        <Header />
        <ProductR />
      </main>
      <Footer/> 
    </>
  )
}

export default App
