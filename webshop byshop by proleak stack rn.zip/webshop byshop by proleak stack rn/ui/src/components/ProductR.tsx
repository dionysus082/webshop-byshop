import { useEffect, useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { IoBagCheckOutline } from "react-icons/io5";
import { Link } from "react-router-dom";
import { HiOutlineExclamationTriangle } from "react-icons/hi2";
import { BlurFade } from "@/components/magicui/blur-fade";

function stripHTML(html: string): string {
    if (!html) return "";
    const doc = new DOMParser().parseFromString(html, "text/html");
    return doc.body.textContent || "";
}

function ProductR() {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        fetch("https://byshop.me/api/product")
            .then((res) => res.json())
            .then((data) => {
                const filtered = data.filter((item: any) => item.id !== "100");
                setProducts(filtered);
            })
            .catch((error) =>
                console.error("เกิดข้อผิดพลาดในการโหลดสินค้า:", error)
            );
    }, []);

    return (
        <section className="flex justify-center px-3 pt-5">
            <div className="w-full max-w-screen-lg">
                <div className="flex justify-between items-center">
                    <h3 className="th text-lg">สินค้าแนะนำสำหรับคุณ</h3>
                    <Button>
                        <Link to={'/store'}>
                            ดูสินค้าทั้งหมด
                        </Link>
                    </Button>
                </div>

                <BlurFade delay={0.25} inView>
                    <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5">
                        {products.slice(0, 10).map((product: any) => {
                            const isOutOfStock = product.stock === "0" || product.status === "สินค้าหมด";

                            return (
                                <Link to={`/store/${product.id}`} key={product.id}>
                                    <Card
                                        className={`p-2 hover:shadow-md transition-shadow duration-200 ${isOutOfStock ? "grayscale opacity-80" : ""
                                            }`}
                                    >
                                        <img
                                            src={product.img}
                                            alt={product.name}
                                            className="w-full rounded-md object-cover h-[150px]"
                                        />
                                        <div className="mt-2">
                                            <h4 className="th text-sm line-clamp-1">{product.name}</h4>
                                            <p className="text-xs text-zinc-500 line-clamp-2">
                                                {stripHTML(product.product_info)}
                                            </p>
                                            <p className="text-red-500 mt-1">฿{product.price}</p>
                                            <Button
                                                className="mt-2 w-full flex justify-center gap-2"
                                                disabled={isOutOfStock}
                                            >
                                                {isOutOfStock ? (<HiOutlineExclamationTriangle />) : (<IoBagCheckOutline />)} {isOutOfStock ? "สินค้าหมด" : "สั่งซื้อ"}
                                            </Button>
                                        </div>
                                    </Card>
                                </Link>
                            );
                        })}
                    </div>
                </BlurFade>
            </div>
        </section>
    );
}

export default ProductR;