import { Link } from "react-router-dom"
import { Button } from "./ui/button";
import { cn } from "@/lib/utils";
import { AnimatedGridPattern } from "@/components/magicui/animated-grid-pattern";
import { BlurFade } from "@/components/magicui/blur-fade";

import { useAuth } from "@/context/AuthContext";

function Header() {
    const { isVerified } = useAuth();
  return (
    <header className="flex justify-center px-3 py-[80px] relative overflow-hidden">
        <AnimatedGridPattern
            numSquares={30}
            maxOpacity={0.1}
            duration={3}
            repeatDelay={1}
            className={cn(
            "[mask-image:radial-gradient(500px_circle_at_center,white,transparent)]",
            "inset-x-0 inset-y-[-30%] h-[200%] skew-y-12",
            )}
        />
        <div className="w-full max-w-screen-lg">

            <div>
                <BlurFade delay={0.25} inView>
                <h1 className="th text-lg">ร้านค้าออนไลน์ บริการแอพพรีเมี่ยม บัตรเติมเงิน</h1>
                <div className="flex justify-start">
                    <p className="text-sm text-zinc-500 max-w-[600px]">
                        ศูนย์รวมสินค้าดิจิทัลครบวงจร ทั้งบัตรเติมเงิน เกม โค้ดพรีเมี่ยมจากแอปต่างๆ และบริการสุดพิเศษที่เชื่อถือได้ พร้อมให้บริการด้วยความรวดเร็ว ปลอดภัย และสะดวกสบาย รองรับการใช้งานทุกแพลตฟอร์ม
                    </p>
                </div>
                </BlurFade>
                <BlurFade delay={0.25 * 2} inView>
                <div className="mt-5 flex justify-start items-center space-x-2">
                    <Button>
                        <Link to={'/store'}>
                            เริ่มต้นใช้งาน
                        </Link>
                    </Button>
                    {!isVerified && (
                        <Button variant={'secondary'}>
                            <Link to={'/'}>
                                สมัครสมาชิก
                            </Link>
                        </Button>
                    )}
                </div>
                </BlurFade>
            </div>

        </div>
    </header>
  )
}

export default Header