import { Link } from "react-router-dom";
import { Button } from "./ui/button";
import { ModeToggle } from "./mode-toggle";

import { useAuth } from "@/context/AuthContext";
import useLogout from "@/hooks/auth/useLogOut";

import { LiaUserTieSolid } from "react-icons/lia";

import { useProfile } from "@/hooks/profile/useProfile";

import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge"

function Nav() {
    const { isVerified } = useAuth();
    const { handleLogout } = useLogout();
    const { profile } = useProfile();
    return (
        <nav className="flex justify-center px-3 py-2 sticky top-0 backdrop-blur-2xl bg-white/50 dark:bg-zinc-950/50 border-b border-zinc-200 dark:border-b-zinc-900/50 select-none z-50">
            <div className="w-full max-w-screen-lg flex justify-between items-center">

                <div className="flex items-center space-x-5">
                    <div>
                        <Link to={'/'}>
                            <h2 className="font-bold text-lg pop">PROLEAK</h2>
                        </Link>
                    </div>
                    <ul className="flex items-center">
                        <li>
                            <Button variant={'ghost'}>
                                <Link to={'/topup'}>
                                    เติมเงิน
                                </Link>
                            </Button>
                        </li>
                        <li>
                            <Button variant={'ghost'}>
                                <Link to={'/store'}>
                                    ร้านค้า
                                </Link>
                            </Button>
                        </li>
                        <li>
                            <Button variant={'ghost'}>
                                <Link to={'/contact'}>
                                    ติดต่อ
                                </Link>
                            </Button>
                        </li>
                    </ul>
                </div>

                <div className="flex items-center space-x-2">
                    <ModeToggle />
                    {isVerified ? (
                        <>
                            <Dialog>
                                <DialogTrigger>
                                    <Button variant={'ghost'} className="cursor-pointer">
                                        <LiaUserTieSolid />
                                    </Button>
                                </DialogTrigger>
                                <DialogContent>
                                    <DialogHeader>
                                        <h2 className="th text-lg">ข้อมูลส่วนตัว</h2>
                                    </DialogHeader>
                                    <div className="flex justify-between items-center">
                                        <div>
                                            <div className="flex items-start gap-1 uppercase pop font-semibold">
                                                {profile?.username} <Badge variant={'outline'} className="pop text-xs">PROLEAK</Badge>
                                            </div>
                                            <code className="text-xs text-zinc-500">
                                                {profile?.email}
                                            </code>
                                        </div>
                                        <div>
                                            <h2 className="pop font-bold text-transparent bg-clip-text bg-gradient-to-tr from-black to-white">฿ {profile?.points}</h2>
                                        </div>
                                    </div>
                                    <div className="flex justify-end">
                                        <div>
                                            <Button>
                                                <Link to={'/profile/history/orders'}>
                                                    ประวัติการสั่งซื้อ
                                                </Link>
                                            </Button>
                                        </div>
                                    </div>
                                </DialogContent>
                            </Dialog>
                            <Button onClick={handleLogout} variant={'outline'}>
                                ออกจากระบบ
                            </Button>
                        </>
                    ) : (
                        <>
                            <Button variant={'ghost'}>
                                <Link to={'/signup'}>
                                    สมัครสมาชิก
                                </Link>
                            </Button>
                            <Button variant={'default'}>
                                <Link to={'/signin'}>
                                    เข้าสู่ระบบ
                                </Link>
                            </Button>
                        </>
                    )}
                </div>

            </div>
        </nav>
    )
}

export default Nav