function Footer() {
  return (
    <footer className='flex justify-center px-3 py-[20px] select-none'>
        <div className='w-full max-w-screen-lg'>

            <h1 className='pop font-bold text-[120px] text-center bg-gradient-to-b dark:from-white dark:to-black from-black to-white bg-clip-text text-transparent'>
                PROLEAK
            </h1>
            <p className="pop text-center text-xs text-zinc-400 dark:text-zinc-600">© 2024 PROLEAK INNOVATION</p>

        </div>
    </footer>
  )
}

export default Footer