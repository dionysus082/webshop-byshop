import Nav from "@/components/Nav";

function Notfound() {
  return (
    <div>
        <Nav />
        <main className="min-h-screen flex justify-center items-center">
            <h1 className='pop font-bold text-[80px] text-center bg-gradient-to-b dark:from-white dark:to-black from-black to-white bg-clip-text text-transparent'>
                404
            </h1>
        </main>
    </div>
  )
}

export default Notfound