import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";

function Contact() {
    return (
        <div>
            <Nav />
            <main className="min-h-screen">
                <section className="flex justify-center px-3 py-5">
                    <div className="w-full max-w-screen-lg">

                        <div>
                            <h1 className="th text-lg">ช่องทางการติดต่อเรา</h1>
                        </div>

                        <div className="mt-5 grid grid-cols-4 gap-5">

                            <Link to={'/'}>
                                <div className="border bg-zinc-50 p-2 rounded-md dark:bg-zinc-900/30 dark:border-zinc-900/50 flex items-center space-x-5">
                                    <div>
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/960px-Instagram_icon.png" className="w-[50px] h-[50px]" alt="" />
                                    </div>
                                    <div>
                                        <h3 className="pop font-bold">Instagram</h3>
                                    </div>
                                </div>
                            </Link>
                            <Link to={'/'}>
                                <div className="border bg-zinc-50 p-2 rounded-md dark:bg-zinc-900/30 dark:border-zinc-900/50 flex items-center space-x-5">
                                    <div>
                                        <img src="https://cdn-icons-png.flaticon.com/512/5968/5968756.png" className="w-[50px] h-[50px]" alt="" />
                                    </div>
                                    <div>
                                        <h3 className="pop font-bold">Instagram</h3>
                                    </div>
                                </div>
                            </Link>

                        </div>

                    </div>
                </section>
            </main>
            <Footer />
        </div>
    )
}

export default Contact