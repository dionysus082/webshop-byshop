import { Input } from "@/components/ui/input";
import { useState, type FormEvent } from "react";
import axios from "axios";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Card } from "@/components/ui/card"

import {
    Dialog,
    DialogContent,
    DialogTrigger,
    DialogHeader,
} from "@/components/ui/dialog";

function TopUpTrueMoney() {
    const [link, setLink] = useState("");
    const [loading, setLoading] = useState(false);
    const [isDialogOpen, setIsDialogOpen] = useState(false);

    const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        if (!link) {
            toast.error("กรุณาใส่ลิ้งค์อั่งเปา ทรูมันนี่");
            return;
        }

        setLoading(true);

        try {
            const response = await axios.post(
                "http://localhost:3000/topup/truemoney",
                { link },
                { withCredentials: true }
            );

            if (response.data?.status) {
                toast.success(`เติมเงินสำเร็จ จำนวน ${response.data.amount} บาท`);
                setIsDialogOpen(false);
                setLink("");
            } else {
                toast.error(response.data.message || "เกิดข้อผิดพลาด");
            }
        } catch (error: any) {
            const msg = error.response?.data?.message || "ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์";
            toast.error(msg);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                    <Card className="p-2 cursor-pointer">
                        <div className="flex justify-center">
                            <img src="https://cdn-icons-png.flaticon.com/512/6738/6738905.png" className="w-[80px] h-[80px]" alt="" />
                        </div>
                        <div>
                            <h3 className="th text-lg text-center">อั่งเปา ทรูมันนี่</h3>
                            <div className="flex justify-center">
                                <Badge variant="outline">ค่าธรรมเนียม 0 บาท</Badge>
                            </div>
                        </div>
                    </Card>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <h1 className="th text-lg">อั่งเปา ทรูมันนี่</h1>
                        <p className="text-zinc-500 text-xs">
                            ใส่ลิ้งค์ อั่งเปา ทรูมันนี่ เพื่อเติมเงิน
                        </p>
                    </DialogHeader>
                    <form className="space-y-3" onSubmit={handleSubmit}>
                        <div className="grid grid-cols-1 gap-1">
                            <Input
                                id="link"
                                name="link"
                                value={link}
                                onChange={(e) => setLink(e.target.value)}
                                placeholder="https://gift.truemoney.com/campaign/?v=..."
                            />
                        </div>

                        <div className="flex justify-end">
                            <Button
                                variant={'default'}
                                type="submit"
                                disabled={loading}
                            >
                                {loading ? "กำลังดำเนินการ..." : "เติมเงิน"}
                            </Button>
                        </div>
                    </form>
                </DialogContent>
            </Dialog>
        </div>
    );
}

export default TopUpTrueMoney;