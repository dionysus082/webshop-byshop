import Nav from "@/components/Nav";
import Footer from "@/components/Footer";

import TopUpVerifySlip from "./verifyslip/TopUpVerifySlip";
import TopUpTrueMoney from "./truemoney/TopUpTrueMoney";

import { BlurFade } from "@/components/magicui/blur-fade";

function TopUp() {
  return (
    <div>
      <Nav />
      <main className="min-h-screen">
        <div className="flex justify-center px-3 py-5">
          <div className="w-full max-w-screen-lg">

            <div>
              <h1 className="th text-lg">เลือกช่องทาง การเติมเงิน</h1>
            </div>

            <BlurFade delay={0.25} inView>
              <div className="mt-5 grid grid-cols-4 gap-5">

                <TopUpTrueMoney />
                <TopUpVerifySlip />

              </div>
            </BlurFade>

          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

export default TopUp