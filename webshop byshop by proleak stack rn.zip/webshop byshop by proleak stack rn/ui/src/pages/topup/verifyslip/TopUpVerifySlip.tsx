import { Input } from "@/components/ui/input";

import { useState, type ChangeEvent, type FormEvent } from "react";
import axios from "axios";
import jsQR from "jsqr";

import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PiCopyDuotone } from "react-icons/pi";
import { Card } from "@/components/ui/card"

import {
    Dialog,
    DialogContent,
    DialogTrigger,
    DialogHeader,
} from "@/components/ui/dialog";

function TopUpVerifySlip() {
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);

    const handleFileChange = (event: ChangeEvent<HTMLInputElement>): void => {
        const file = event.target.files?.[0];
        if (file) {
            setSelectedFile(file);
        }
    };


    const recipient = {
        name: "นาย ปลาตั้งโก๋ สามีมาก",
        number: "123524365",
        bank_name: "กสิกรไทย",
        bank_logo: "https://www.kasikornbank.com/SiteCollectionDocuments/about/img/logo/logo.png"
    };

    const copyAccountNumber = async () => {
        try {
            await navigator.clipboard.writeText(recipient.number);
            toast.success("คัดลอกเลขบัญชีสำเร็จแล้ว!");
        } catch (err) {
            console.error(err);
            toast.error("ไม่สามารถคัดลอกเลขบัญชีได้");
        }
    };

    const readQrCodeFromImage = (imageFile: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e: ProgressEvent<FileReader>): void => {
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');

                    if (!ctx) {
                        reject("ไม่สามารถรับบริบท Canvas ได้");
                        return;
                    }

                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0, img.width, img.height);

                    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                    const code = jsQR(imageData.data, imageData.width, imageData.height);

                    if (code) {
                        resolve(code.data);
                    } else {
                        reject("ไม่พบ QR Code ในรูปภาพ");
                    }
                };
                img.onerror = () => reject("ไม่สามารถโหลดรูปภาพได้");
                img.src = e.target?.result as string;
            };
            reader.onerror = () => reject("ไม่สามารถอ่านไฟล์ได้");
            reader.readAsDataURL(imageFile);
        });
    };

    const handleSubmit = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
        event.preventDefault();
        setLoading(true);

        if (!selectedFile) {
            toast.error("กรุณาอัปโหลดรูปภาพสลิป");
            setLoading(false);
            return;
        }

        try {
            const data = await readQrCodeFromImage(selectedFile);

            const response = await axios.post(
                "http://localhost:3000/topup/check_slip",
                { qrcode_text: data },
                { withCredentials: true }
            );

            if (response.data.success) {
                toast.success(response.data.massage_th || "ตรวจสอบสลิปสำเร็จ!");
                setIsDialogOpen(false);
            } else {
                toast.error(response.data.massage_th || "เกิดข้อผิดพลาดในการตรวจสอบสลิป");
            }
        } catch (error: unknown) {
            console.error("Error during slip check:", error);
            let errorMessage = "เกิดข้อผิดพลาดที่ไม่คาดคิด";

            if (axios.isAxiosError(error)) {
                if (error.response) {
                    errorMessage =
                        error.response.data?.massage_th ||
                        error.response.data?.massage_en ||
                        error.response.data?.message ||
                        `ข้อผิดพลาดจากเซิร์ฟเวอร์: ${error.response.status}`;
                } else if (error.request) {
                    errorMessage = "ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้ กรุณาลองใหม่ภายหลัง";
                } else {
                    errorMessage = `เกิดข้อผิดพลาดในการตั้งค่าคำขอ: ${error.message}`;
                }
            } else if (typeof error === "string") {
                errorMessage = error;
            } else if (error instanceof Error) {
                errorMessage = error.message;
            }

            toast.error(errorMessage);
        } finally {
            setLoading(false);
        }
    };
    return (
        <div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                    <Card className="p-2 cursor-pointer">
                        <div className="flex justify-center">
                            <img src="https://apiportal.kasikornbank.com/bucket/SiteCollectionDocuments/assets/theme/img/type-img-04.png" className="w-[80px] h-[80px] object-cover" alt="" />
                        </div>
                        <div>
                            <h3 className="th text-lg text-center">ตรวจสอบสลิป </h3>
                            <div className="flex justify-center">
                                <Badge variant="outline">ค่าธรรมเนียม 0 บาท</Badge>
                            </div>
                        </div>
                    </Card>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <h1 className="th text-lg">
                            ตรวจสอบสลิป
                        </h1>
                        <p className="text-zinc-500 text-xs">
                            อัปโหลดรูปภาพสลิปเพื่อตรวจสอบ QR Code
                        </p>
                    </DialogHeader>
                    <Card className="p-2">
                        <div className="space-y-2">
                            <Button variant={'outline'} className="text-xs w-full">
                                {recipient.name}
                            </Button>
                            <div className="flex items-center space-x-2">
                                <Button variant={'outline'} className="text-xs basis-2/4" id={'banknumber'}>
                                    {recipient.number}
                                </Button>
                                <Button variant={'outline'} className=" flex text-xs items-center justify-center gap-2 basis-2/4">
                                    <img className="w-[20px] h-[20px] rounded-md" src={recipient.bank_logo} alt={recipient.bank_name} /> {recipient.bank_name}
                                </Button>
                            </div>
                        </div>
                    </Card>
                    <div className="flex justify-end">
                        <Button variant={'outline'} onClick={copyAccountNumber} className="text-xs flex items-center gap-2"><PiCopyDuotone /> คัดลอกเลขบัญชี</Button>
                    </div>
                    <form className="space-y-3" onSubmit={handleSubmit}>
                        <div className="grid grid-cols-1 gap-1">
                            <Input
                                id="slipFile"
                                type="file"
                                accept="image/*"
                                onChange={handleFileChange}
                            />
                        </div>

                        <div className="flex justify-end">
                            <Button
                                variant={'default'}
                                type="submit"
                                disabled={loading || !selectedFile}
                            >
                                {loading ? "กำลังตรวจสอบ..." : "ตรวจสอบสลิป"}
                            </Button>
                        </div>
                    </form>
                </DialogContent>
            </Dialog>
        </div>
    )
}

export default TopUpVerifySlip