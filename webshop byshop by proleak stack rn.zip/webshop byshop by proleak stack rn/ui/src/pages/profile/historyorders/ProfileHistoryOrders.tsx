import { useEffect, useState } from "react";
import axios from "axios";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
} from "@/components/ui/dialog";
import parse from "html-react-parser";

type Order = {
    orderid: string;
    status: string;
    price: string;
    name: string;
    time: string;
    img?: string;
    info?: string;
};

export default function ProfileHistoryOrders() {
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState(true);

    const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
    const [open, setOpen] = useState(false);

    useEffect(() => {
        async function fetchOrders() {
            try {
                const response = await axios.get("http://localhost:3000/profile/orders", {
                    withCredentials: true,
                });
                const data = response.data;

                if (data.success && Array.isArray(data.orders)) {
                    setOrders(data.orders);
                }
            } catch (error) {
                console.error("Error fetching orders:", error);
            } finally {
                setLoading(false);
            }
        }
        fetchOrders();
    }, []);

    function openDialog(order: Order) {
        setSelectedOrder(order);
        setOpen(true);
    }

    function closeDialog() {
        setOpen(false);
        setSelectedOrder(null);
    }

    return (
        <div>
            <Nav />
            <main className="min-h-screen px-3 py-5 max-w-screen-lg mx-auto">
                <h1 className="text-2xl th mb-5">ประวัติการสั่งซื้อ</h1>
                {loading ? (
                    <p>Loading...</p>
                ) : orders.length === 0 ? (
                    <p>ยังไม่มีรายการสั่งซื้อ</p>
                ) : (
                    <Table className="mb-8">
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[100px]">Order ID</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Product</TableHead>
                                <TableHead>Time</TableHead>
                                <TableHead className="text-right">Amount</TableHead>
                                <TableHead className="text-center w-[100px]">รายละเอียด</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {orders.map((order) => (
                                <TableRow key={order.orderid}>
                                    <TableCell className="font-mono">{order.orderid}</TableCell>
                                    <TableCell>
                                        <Badge
                                            variant={order.status === "success" ? "secondary" : "destructive"}
                                            className={order.status === "success" ? "bg-green-600 text-white" : ""}
                                        >
                                            {order.status === "success" ? "สำเร็จ" : order.status}
                                        </Badge>
                                    </TableCell>
                                    <TableCell>
                                        <div className="flex items-center space-x-4">
                                            {order.img && (
                                                <img
                                                    src={order.img}
                                                    alt={order.name}
                                                    className="w-12 h-12 rounded object-cover"
                                                />
                                            )}
                                            <div>
                                                <p className="th">{order.name}</p>
                                            </div>
                                        </div>
                                    </TableCell>
                                    <TableCell>{new Date(order.time).toLocaleString("th-TH")}</TableCell>
                                    <TableCell className="text-right">{parseFloat(order.price).toFixed(2)} ฿</TableCell>
                                    <TableCell className="text-center">
                                        <Button size="sm" onClick={() => openDialog(order)}>
                                            ดูรายละเอียด
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                )}

                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogContent className="max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                            <h1 className="th text-lg">รายละเอียด Order {selectedOrder?.orderid}</h1>
                            <DialogDescription>
                                <div className="prose max-w-full">
                                    {selectedOrder?.info ? parse(selectedOrder.info) : <p>ไม่มีรายละเอียด</p>}
                                </div>
                            </DialogDescription>
                        </DialogHeader>
                        <DialogFooter>
                            <Button onClick={closeDialog}>ปิด</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </main>
            <Footer />
        </div>
    );
}