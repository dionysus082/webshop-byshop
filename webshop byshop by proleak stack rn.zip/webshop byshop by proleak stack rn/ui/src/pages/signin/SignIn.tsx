import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import {
    Card,
    CardAction,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

function SignIn() {
    const [form, setForm] = useState({ username: "", password: "" });
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const res = await axios.post("http://localhost:3000/auth/login", form, {
                withCredentials: true,
            });

            if (res.data.success) {
                toast.success("เข้าสู่ระบบสำเร็จ!");
                setTimeout(() => {
                    navigate("/");
                    window.location.reload();
                }, 1000);
            }
        } catch (err: any) {
            const msg =
                err.response?.data?.message || "เกิดข้อผิดพลาดในการเข้าสู่ระบบ";
            toast.error(msg);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <Nav />
            <main className="min-h-screen flex justify-center items-center">
                <Card className="w-full max-w-sm">
                    <CardHeader>
                        <CardTitle>เข้าสู่ระบบ</CardTitle>
                        <CardDescription className="pop text-sm -mt-1">SignIn</CardDescription>
                        <CardAction>
                            <h2 className="pop font-bold">PROLEAK</h2>
                        </CardAction>
                    </CardHeader>
                    <CardContent>
                        <form className="space-y-3" onSubmit={handleSubmit}>
                            <Input
                                placeholder="ชื่อผู้ใช้"
                                name="username"
                                value={form.username}
                                onChange={handleChange}
                                required
                            />
                            <Input
                                placeholder="รหัสผ่าน"
                                name="password"
                                type="password"
                                value={form.password}
                                onChange={handleChange}
                                required
                            />
                            <div className="flex justify-end">
                                <Button variant="default" type="submit" disabled={loading}>
                                    {loading ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </main>
            <Footer />
        </div>
    );
}

export default SignIn;