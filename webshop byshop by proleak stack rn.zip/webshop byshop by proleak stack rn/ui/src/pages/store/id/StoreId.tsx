import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { BlurFade } from "@/components/magicui/blur-fade";
import { toast } from "sonner";

function stripHTML(html: string): string {
    if (!html) return "";
    const doc = new DOMParser().parseFromString(html, "text/html");
    return doc.body.textContent || "";
}

function StoreId() {
    const { id } = useParams();
    const [product, setProduct] = useState<any | null>(null);
    const [loading, setLoading] = useState(true);
    const [quantity, setQuantity] = useState(1);
    const [buying, setBuying] = useState(false);

    useEffect(() => {
        if (!id) return;

        axios
            .get(`https://byshop.me/api/product`, { params: { id } })
            .then((response) => {
                const data = response.data;
                const item = Array.isArray(data) ? data[0] : data;
                setProduct(item || null);
                setLoading(false);
            })
            .catch((error) => {
                console.error("โหลดสินค้าผิดพลาด:", error);
                setLoading(false);
            });
    }, [id]);

    const handleBuy = async () => {
        if (!id || quantity <= 0) {
            toast.error("กรุณาระบุจำนวนให้ถูกต้อง");
            return;
        }

        setBuying(true);

        try {
            const formData = new FormData();
            formData.append("product_id", id);
            formData.append("quantity", quantity.toString());

            const res = await axios.post(
                "http://localhost:3000/order/buy",
                formData,
                {
                    withCredentials: true,
                    headers: {
                        "Content-Type": "multipart/form-data",
                    },
                }
            );

            toast.success(`✅ สั่งซื้อสำเร็จ ${res.data.successfulOrders.length} รายการ`);
        } catch (err: any) {
            toast.error(`❌ สั่งซื้อผิดพลาด`);
        } finally {
            setBuying(false);
        }
    };


    return (
        <div>
            <Nav />
            <main className="min-h-screen">
                <section className="flex justify-center px-3 py-5">
                    <div className="w-full max-w-screen-md">
                        <BlurFade delay={0.25} inView>
                            {loading ? (
                                <Card className="p-5 space-y-4">
                                    <Skeleton className="w-full h-[200px] rounded-md" />
                                    <Skeleton className="w-1/2 h-6" />
                                    <Skeleton className="w-1/4 h-5" />
                                    <Skeleton className="w-full h-10" />
                                </Card>
                            ) : product ? (
                                <Card className="p-5 space-y-4">
                                    <img
                                        src={product.img}
                                        alt={product.name}
                                        className="w-full h-[200px] object-contain rounded-md"
                                    />
                                    <div className="space-y-1">
                                        <h1 className="text-xl th">{product.name}</h1>
                                        <Badge variant="outline" className="text-xs">
                                            หมวดหมู่: {product.category}
                                        </Badge>
                                        <p className="text-zinc-600 text-sm">
                                            {stripHTML(product.product_info)}
                                        </p>
                                        <p className="text-red-500 th text-lg">
                                            ราคา: ฿{product.price}
                                        </p>
                                        <p className="text-sm text-zinc-500">
                                            สถานะ: {product.status} | คงเหลือ: {product.stock}
                                        </p>
                                    </div>

                                    {product.stock !== "0" &&
                                        product.status !== "สินค้าหมด" ? (
                                        <div className="flex justify-end items-center space-x-2">
                                            <div className="flex items-center space-x-2">
                                                <Button
                                                    variant="outline"
                                                    onClick={() =>
                                                        setQuantity((prev) => Math.max(prev - 1, 1))
                                                    }
                                                >
                                                    ลบ
                                                </Button>
                                                <Input
                                                    type="number"
                                                    value={quantity}
                                                    onChange={(e) =>
                                                        setQuantity(Math.max(Number(e.target.value), 1))
                                                    }
                                                    className="w-[200px] text-center"
                                                />
                                                <Button
                                                    variant="outline"
                                                    onClick={() =>
                                                        setQuantity((prev) => prev + 1)
                                                    }
                                                >
                                                    เพิ่ม
                                                </Button>
                                            </div>
                                            <Button
                                                onClick={handleBuy}
                                                disabled={buying}
                                            >
                                                {buying ? "กำลังสั่งซื้อ..." : "สั่งซื้อสินค้า"}
                                            </Button>
                                        </div>
                                    ) : (
                                        <p className="text-sm text-red-500 text-center">
                                            สินค้าหมดชั่วคราว
                                        </p>
                                    )}
                                </Card>
                            ) : (
                                <p className="text-center text-zinc-500">ไม่พบข้อมูลสินค้านี้</p>
                            )}
                        </BlurFade>
                    </div>
                </section>
            </main>
            <Footer />
        </div>
    );
}

export default StoreId;