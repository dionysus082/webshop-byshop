import { useEffect, useState } from 'react';
import axios from 'axios';
import { serverName } from '@/config/server';

export interface Profile {
  username: string;
  email: string;
  points: number;
}

export const useProfile = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<any>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      setLoading(true);
      try {
        const res = await axios.get<{ success: boolean; user: Profile }>(`${serverName}/profile`, {
          withCredentials: true,
        });

        if (res.data.success) {
          setProfile(res.data.user);
          setError(null);
        } else {
          setError('ไม่สามารถโหลดข้อมูลผู้ใช้ได้');
          setProfile(null);
        }
      } catch (err) {
        setError(err);
        setProfile(null);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  return { profile, loading, error };
};