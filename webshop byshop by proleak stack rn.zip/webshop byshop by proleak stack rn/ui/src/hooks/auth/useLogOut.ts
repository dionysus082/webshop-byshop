import axios from 'axios';
import { serverName } from '@/config/server';
import { toast } from 'sonner';

const useLogout = () => {
    const handleLogout = async () => {
        try {
            await axios.get(`${serverName}/auth/logout`, { withCredentials: true });
            toast.success('ออกจากระบบสำเร็จ');
            setTimeout(() => {
                window.location.href = "/";
            }, 1000);
        } catch (error) {
            toast.error('Logout ล้มเหลว');
        }
    };

    return { handleLogout };
};

export default useLogout;