import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css';

import { AuthProvider } from './context/AuthContext.tsx';

import Protected from './auth/Protected.tsx';
import ReversProtected from './auth/ReversProtected.tsx';

import { Toaster } from "@/components/ui/sonner";

import App from './App.tsx';
import Notfound from './pages/notfound/Notfound.tsx';
import TopUp from './pages/topup/TopUp.tsx';
import Contact from './pages/contact/Contact.tsx';
import Store from './pages/store/Store.tsx';
import StoreId from './pages/store/id/StoreId.tsx';
import SignIn from './pages/signin/SignIn.tsx';
import SignUp from './pages/signup/SignUp.tsx';
import ProfileHistoryOrders from './pages/profile/historyorders/ProfileHistoryOrders.tsx';

import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";

import { ThemeProvider } from "@/components/theme-provider";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <Notfound />
  },
  {
    path: "/topup",
    element: <Protected><TopUp /></Protected>,
  },
  {
    path: "/profile/history/orders",
    element: <Protected><ProfileHistoryOrders /></Protected>,
  },
  {
    path: "/contact",
    element: <Contact />,
  },
  {
    path: "/store",
    element: <Store />,
  },
  {
    path: "/store/:id",
    element: <StoreId />,
  },
  {
    path: "/signin",
    element: <ReversProtected><SignIn /></ReversProtected>,
  },
  {
    path: "/signup",
    element: <ReversProtected><SignUp /></ReversProtected>,
  },
]);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
        <RouterProvider router={router} />
        <Toaster />
      </ThemeProvider>
    </AuthProvider>
  </StrictMode>,
)
